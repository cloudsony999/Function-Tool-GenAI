# Java 25 + Gemini Training — 152 Runnable Programs

## Requirements
- JDK 25
- Maven 3.9+
- Gemini Developer API key
- Internet connection

## Configure API key (PowerShell)
```powershell
$env:GOOGLE_API_KEY="YOUR_API_KEY"
```
The SDK's current README recommends GOOGLE_API_KEY. Do not print or commit it.

## Build
```powershell
mvn clean compile
```

## Run any program
```powershell
mvn exec:java -Dexec.mainClass="com.training.gemini.Program001"
```
Replace Program001 with the program class you want.

Programs 001–100 are prompt practice and request generation.
Programs 101–115 demonstrate request configuration.
Programs 116–125 demonstrate advanced SDK patterns (streaming, async, token count, schema, function calling, and file upload).
Programs 126–145 are Java-only practice utilities.
Programs 146–150 are additional classroom use cases. Programs 151–152 are media-generation examples (image and text-to-speech) using REST payloads from Java.

SDK version pinned in this project: 2.6.0
Model used in text examples: gemini-3.8-flash
Check current model availability and API feature compatibility before classroom use.

## Important
- Gemini responses are nondeterministic: printed output will vary.
- The PDF includes every source code file in this project.
- Some media features require suitable files, permissions, model availability, and account quotas.


## Media generation programs

Program151: Gemini image generation via the REST generateContent endpoint; saves generated image bytes.
Program152: Gemini text-to-speech via REST; wraps returned PCM bytes in a WAV file.
