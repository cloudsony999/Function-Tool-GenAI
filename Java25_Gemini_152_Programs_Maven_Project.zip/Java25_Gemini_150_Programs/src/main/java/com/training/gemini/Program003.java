package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 3: Generative AI. */
public class Program003 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain Generative AI and contrast it with traditional programming.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
