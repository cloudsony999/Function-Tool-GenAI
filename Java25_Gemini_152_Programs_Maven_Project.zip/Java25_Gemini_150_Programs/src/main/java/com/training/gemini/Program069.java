package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 69: Comparison. */
public class Program069 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Compare Java and Python for backend development.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
