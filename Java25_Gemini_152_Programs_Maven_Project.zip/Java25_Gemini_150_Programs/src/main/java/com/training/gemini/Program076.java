package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 76: Sentiment. */
public class Program076 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Analyze sentiment of a sample customer review.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
