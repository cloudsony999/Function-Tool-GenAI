package com.training.gemini;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Base64;

/** Program 151: Generate an image with the Gemini image model using the REST API. */
public class Program151 {
    public static void main(String[] args) throws Exception {
        String apiKey = System.getenv("GOOGLE_API_KEY");
        if (apiKey == null || apiKey.isBlank()) {
            throw new IllegalStateException("Set GOOGLE_API_KEY first.");
        }

        String prompt = args.length > 0
                ? String.join(" ", args)
                : "A cinematic futuristic city at sunset, high detail, wide composition.";

        ObjectMapper mapper = new ObjectMapper();
        ObjectNode root = mapper.createObjectNode();

        ArrayNode contents = root.putArray("contents");
        ObjectNode content = contents.addObject();
        ArrayNode parts = content.putArray("parts");
        parts.addObject().put("text", prompt);

        ObjectNode generationConfig = root.putObject("generationConfig");
        ArrayNode modalities = generationConfig.putArray("responseModalities");
        modalities.add("TEXT");
        modalities.add("IMAGE");
        ObjectNode imageConfig = generationConfig.putObject("imageConfig");
        imageConfig.put("aspectRatio", "16:9");
        imageConfig.put("imageSize", "1K");

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(
                        "https://generativelanguage.googleapis.com/v1beta/models/"
                        + "gemini-3.1-flash-image:generateContent"))
                .header("x-goog-api-key", apiKey)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(mapper.writeValueAsString(root)))
                .build();

        HttpClient http = HttpClient.newHttpClient();
        HttpResponse<String> response =
                http.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() < 200 || response.statusCode() >= 300) {
            throw new IllegalStateException("API error " + response.statusCode()
                    + ": " + response.body());
        }

        JsonNode json = mapper.readTree(response.body());
        JsonNode responseParts = json.path("candidates").path(0)
                .path("content").path("parts");

        for (JsonNode part : responseParts) {
            if (part.has("text")) {
                System.out.println(part.get("text").asText());
            }
            JsonNode inlineData = part.path("inlineData");
            if (inlineData.has("data")) {
                byte[] bytes = Base64.getDecoder().decode(inlineData.get("data").asText());
                String mime = inlineData.path("mimeType").asText("image/png");
                String extension = mime.equals("image/jpeg") ? ".jpg" : ".png";
                Path output = Path.of("gemini-generated" + extension);
                Files.write(output, bytes);
                System.out.println("Image saved: " + output.toAbsolutePath());
            }
        }
    }
}