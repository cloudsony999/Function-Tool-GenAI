package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 74: Structured extraction. */
public class Program074 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Extract name, age and skills from a sample paragraph into JSON.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
