package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 29: Lambda. */
public class Program029 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain lambda expressions in Java with two examples.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
