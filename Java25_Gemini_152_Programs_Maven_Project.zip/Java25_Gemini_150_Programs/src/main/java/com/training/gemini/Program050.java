package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 50: Project ideas. */
public class Program050 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Suggest five beginner GenAI Java projects and rank them by difficulty.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
