package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentConfig;
import com.google.genai.types.GenerateContentResponse;

/** Program 114: System + token cap. */
public class Program114 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain Maven dependencies.";
        GenerateContentConfig config =
                GenerateContentConfig.builder()
                        .systemInstruction(com.google.genai.types.Content.fromParts(com.google.genai.types.Part.fromText("Answer as a concise technical trainer."))).maxOutputTokens(180)
                        .build();
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, config);
        System.out.println(response.text());
    }
}
