package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentConfig;
import com.google.genai.types.GenerateContentResponse;

/** Program 105: Top K. */
public class Program105 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain Java exception handling in five bullet points.";
        GenerateContentConfig config =
                GenerateContentConfig.builder()
                        .topK(20)
                        .build();
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, config);
        System.out.println(response.text());
    }
}
