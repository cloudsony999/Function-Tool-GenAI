package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 93: Safety. */
public class Program093 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain safety filters and why applications should validate output.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
