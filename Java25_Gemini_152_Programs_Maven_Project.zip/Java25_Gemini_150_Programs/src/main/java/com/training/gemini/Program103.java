package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentConfig;
import com.google.genai.types.GenerateContentResponse;

/** Program 103: Temperature creative. */
public class Program103 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Invent three creative robot stories in Java-themed settings.";
        GenerateContentConfig config =
                GenerateContentConfig.builder()
                        .temperature(0.9f)
                        .build();
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, config);
        System.out.println(response.text());
    }
}
