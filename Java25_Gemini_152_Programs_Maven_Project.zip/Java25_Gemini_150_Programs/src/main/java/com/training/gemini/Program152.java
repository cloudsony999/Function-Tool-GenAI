package com.training.gemini;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Base64;

/** Program 152: Generate speech with Gemini TTS and save PCM data as a WAV file. */
public class Program152 {
    public static void main(String[] args) throws Exception {
        String apiKey = System.getenv("GOOGLE_API_KEY");
        if (apiKey == null || apiKey.isBlank()) {
            throw new IllegalStateException("Set GOOGLE_API_KEY first.");
        }

        String text = args.length > 0
                ? String.join(" ", args)
                : "Welcome to Java 25 and Gemini AI training.";

        ObjectMapper mapper = new ObjectMapper();
        ObjectNode root = mapper.createObjectNode();
        ArrayNode contents = root.putArray("contents");
        ObjectNode content = contents.addObject();
        content.put("role", "user");
        content.putArray("parts").addObject().put("text",
                "Speak clearly and naturally: " + text);

        ObjectNode generationConfig = root.putObject("generationConfig");
        generationConfig.putArray("responseModalities").add("AUDIO");
        ObjectNode speechConfig = generationConfig.putObject("speechConfig");
        ObjectNode voiceConfig = speechConfig.putObject("voiceConfig");
        voiceConfig.putObject("prebuiltVoiceConfig").put("voiceName", "Kore");

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(
                        "https://generativelanguage.googleapis.com/v1beta/models/"
                        + "gemini-3.8-flash-tts:generateContent"))
                .header("x-goog-api-key", apiKey)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(mapper.writeValueAsString(root)))
                .build();

        HttpClient http = HttpClient.newHttpClient();
        HttpResponse<String> response =
                http.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() < 200 || response.statusCode() >= 300) {
            throw new IllegalStateException("API error " + response.statusCode()
                    + ": " + response.body());
        }

        JsonNode json = mapper.readTree(response.body());
        JsonNode parts = json.path("candidates").path(0)
                .path("content").path("parts");

        byte[] audio = null;
        for (JsonNode part : parts) {
            JsonNode inlineData = part.path("inlineData");
            if (inlineData.has("data")) {
                audio = Base64.getDecoder().decode(inlineData.get("data").asText());
                System.out.println("Audio MIME: "
                        + inlineData.path("mimeType").asText("audio/pcm"));
                break;
            }
        }

        if (audio == null) {
            throw new IllegalStateException("No audio bytes found in response.");
        }

        writeWav(Path.of("gemini-speech.wav"), audio, 24000, 1, 16);
        System.out.println("Saved WAV: " + Path.of("gemini-speech.wav").toAbsolutePath());
    }

    /** Wrap raw PCM bytes in a standard RIFF/WAVE header. */
    private static void writeWav(Path path, byte[] pcm, int sampleRate,
                                int channels, int bitsPerSample) throws IOException {
        int byteRate = sampleRate * channels * bitsPerSample / 8;
        int blockAlign = channels * bitsPerSample / 8;

        try (DataOutputStream out = new DataOutputStream(Files.newOutputStream(path))) {
            writeAscii(out, "RIFF");
            writeLittleEndianInt(out, 36 + pcm.length);
            writeAscii(out, "WAVE");
            writeAscii(out, "fmt ");
            writeLittleEndianInt(out, 16);
            writeLittleEndianShort(out, 1); // PCM format
            writeLittleEndianShort(out, channels);
            writeLittleEndianInt(out, sampleRate);
            writeLittleEndianInt(out, byteRate);
            writeLittleEndianShort(out, blockAlign);
            writeLittleEndianShort(out, bitsPerSample);
            writeAscii(out, "data");
            writeLittleEndianInt(out, pcm.length);
            out.write(pcm);
        }
    }

    private static void writeAscii(DataOutputStream out, String text) throws IOException {
        out.writeBytes(text);
    }

    private static void writeLittleEndianInt(DataOutputStream out, int value) throws IOException {
        out.writeByte(value & 0xff);
        out.writeByte((value >>> 8) & 0xff);
        out.writeByte((value >>> 16) & 0xff);
        out.writeByte((value >>> 24) & 0xff);
    }

    private static void writeLittleEndianShort(DataOutputStream out, int value) throws IOException {
        out.writeByte(value & 0xff);
        out.writeByte((value >>> 8) & 0xff);
    }
}