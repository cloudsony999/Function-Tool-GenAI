package com.training.gemini;

/** Program 128: ConversationTranscript. Java-only practice helper. */
public class Program128 {
    public static void main(String[] args) throws Exception {
        java.util.List<String> turns = new java.util.ArrayList<>();
        turns.add("USER: My name is Riya.");
        turns.add("MODEL: Hello, Riya.");
        turns.add("USER: Explain Java.");
        String transcript = String.join("\n", turns);
        System.out.println(transcript);
    }
}
