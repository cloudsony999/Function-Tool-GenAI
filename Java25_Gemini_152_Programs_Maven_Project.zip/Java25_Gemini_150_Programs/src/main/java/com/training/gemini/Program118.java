package com.training.gemini;
import com.google.genai.Client;
import com.google.genai.types.CountTokensResponse;
/** Estimate input token usage before generation. */
public class Program118 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain Java 25 and Maven.";
        CountTokensResponse result =
                client.models.countTokens("gemini-3.8-flash", prompt, null);
        System.out.println(result);
    }
}