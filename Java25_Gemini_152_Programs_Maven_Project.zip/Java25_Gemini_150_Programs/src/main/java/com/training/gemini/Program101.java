package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentConfig;
import com.google.genai.types.GenerateContentResponse;

/** Program 101: Temperature low. */
public class Program101 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain the difference between ArrayList and LinkedList using factual language.";
        GenerateContentConfig config =
                GenerateContentConfig.builder()
                        .temperature(0.1f)
                        .build();
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, config);
        System.out.println(response.text());
    }
}
