package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 4: LLM. */
public class Program004 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain what a Large Language Model is using a simple analogy.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
