package com.training.gemini;

/** Program 139: PromptHistory. Java-only practice helper. */
public class Program139 {
    public static void main(String[] args) throws Exception {
        java.util.ArrayList<String> history = new java.util.ArrayList<>();
        for (String prompt : new String[]{"Explain Java", "Explain Maven", "Explain Gemini", "Explain tokens", "Explain prompts", "Explain streaming"}) {
            history.add(prompt);
            if (history.size() > 5) history.remove(0);
        }
        System.out.println(history);
    }
}
