package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 96: Audio analysis. */
public class Program096 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Give a prompt to summarize a meeting recording into decisions and actions.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
