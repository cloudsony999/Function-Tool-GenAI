package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 149: Prompt for interview scoring. */
public class Program149 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Create a beginner Java interview scoring rubric out of 100.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
