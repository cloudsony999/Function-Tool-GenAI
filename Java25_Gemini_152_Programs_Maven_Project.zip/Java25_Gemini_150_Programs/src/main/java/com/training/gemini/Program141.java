package com.training.gemini;

/** Program 141: SimpleChatLoop. Java-only practice helper. */
public class Program141 {
    public static void main(String[] args) throws Exception {
        java.util.Scanner sc = new java.util.Scanner(System.in);
        while (true) {
            System.out.print("You (type EXIT): ");
            String line = sc.nextLine();
            if (line.equalsIgnoreCase("EXIT")) break;
            System.out.println("Stored prompt: " + line);
        }
        sc.close();
    }
}
