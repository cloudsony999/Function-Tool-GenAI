package com.training.gemini;

/** Program 127: PromptTemplate. Java-only practice helper. */
public class Program127 {
    public static void main(String[] args) throws Exception {
        String template = "Explain {topic} for {audience}. Include {format}.";
        String prompt = template.replace("{topic}", "Maven")
                .replace("{audience}", "beginners")
                .replace("{format}", "one example");
        System.out.println(prompt);
    }
}
