package com.training.gemini;

/** Program 134: TokenBudget. Java-only practice helper. */
public class Program134 {
    public static void main(String[] args) throws Exception {
        String prompt = "Explain Java in simple English.";
        int roughEstimate = Math.max(1, (prompt.length() + 3) / 4);
        System.out.println("Characters: " + prompt.length());
        System.out.println("Rough estimate (not a tokenizer): " + roughEstimate);
        System.out.println("Use SDK countTokens for actual model token counts.");
    }
}
