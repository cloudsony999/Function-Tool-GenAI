package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 15: Switch. */
public class Program015 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain modern switch expressions in Java 25 with a simple example.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
