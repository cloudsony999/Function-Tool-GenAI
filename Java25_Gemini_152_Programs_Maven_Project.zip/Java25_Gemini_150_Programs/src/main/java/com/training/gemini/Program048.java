package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 48: MCQ. */
public class Program048 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Generate five MCQs on Java OOP with answer key.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
