package com.training.gemini;

/** Program 138: BackoffDemo. Java-only practice helper. */
public class Program138 {
    public static void main(String[] args) throws Exception {
        for (int attempt = 1; attempt <= 5; attempt++) {
            long delayMs = 500L * (1L << (attempt - 1));
            System.out.println("Attempt " + attempt + " delay = " + delayMs + " ms");
        }
    }
}
