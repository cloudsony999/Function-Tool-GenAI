package com.training.gemini;
import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;
import java.util.concurrent.CompletableFuture;
/** Async generation using CompletableFuture. */
public class Program117 {
    public static void main(String[] args) {
        Client client = new Client();
        CompletableFuture<GenerateContentResponse> future =
                client.async.models.generateContent(
                        "gemini-3.8-flash", "Explain asynchronous programming.", null);
        future.thenAccept(response -> System.out.println(response.text())).join();
    }
}