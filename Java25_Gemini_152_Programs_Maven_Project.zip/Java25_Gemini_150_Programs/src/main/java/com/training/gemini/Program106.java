package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentConfig;
import com.google.genai.types.GenerateContentResponse;

/** Program 106: Maximum output. */
public class Program106 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain Java inheritance.";
        GenerateContentConfig config =
                GenerateContentConfig.builder()
                        .maxOutputTokens(120)
                        .build();
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, config);
        System.out.println(response.text());
    }
}
