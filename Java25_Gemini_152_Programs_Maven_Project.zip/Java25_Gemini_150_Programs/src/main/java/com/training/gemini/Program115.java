package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentConfig;
import com.google.genai.types.GenerateContentResponse;

/** Program 115: Config from user. */
public class Program115 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain prompt engineering.";
        GenerateContentConfig config =
                GenerateContentConfig.builder()
                        .temperature(Float.parseFloat(args.length > 0 ? args[0] : "0.4"))
                        .build();
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, config);
        System.out.println(response.text());
    }
}
