package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 55: Machine learning. */
public class Program055 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain supervised and unsupervised learning with examples.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
