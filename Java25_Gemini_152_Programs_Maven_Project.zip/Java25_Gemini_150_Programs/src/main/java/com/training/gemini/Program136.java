package com.training.gemini;

/** Program 136: JsonFileReader. Java-only practice helper. */
public class Program136 {
    public static void main(String[] args) throws Exception {
        java.nio.file.Path path = java.nio.file.Path.of("sample.json");
        if (java.nio.file.Files.exists(path)) System.out.println(java.nio.file.Files.readString(path));
        else System.out.println("Create sample.json first.");
    }
}
