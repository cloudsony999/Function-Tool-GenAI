package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 52: Oracle SQL. */
public class Program052 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Write Oracle SQL to find employees above average salary and explain it.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
