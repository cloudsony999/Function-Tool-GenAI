package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 43: Translation. */
public class Program043 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Translate a short welcome message to Hindi and Bengali.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
