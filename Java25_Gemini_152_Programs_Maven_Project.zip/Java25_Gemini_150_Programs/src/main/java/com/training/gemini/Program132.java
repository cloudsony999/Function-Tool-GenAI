package com.training.gemini;

/** Program 132: PromptMenu. Java-only practice helper. */
public class Program132 {
    public static void main(String[] args) throws Exception {
        java.util.Scanner sc = new java.util.Scanner(System.in);
        System.out.println("1 Java\n2 SQL\n3 GenAI");
        System.out.print("Choose: ");
        String choice = sc.nextLine();
        String prompt = switch (choice) {
            case "1" -> "Explain Java OOP.";
            case "2" -> "Explain SQL joins.";
            case "3" -> "Explain GenAI.";
            default -> "Unknown choice.";
        };
        System.out.println(prompt);
        sc.close();
    }
}
