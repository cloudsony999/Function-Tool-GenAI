package com.training.gemini;

/** Program 142: CommandRouter. Java-only practice helper. */
public class Program142 {
    public static void main(String[] args) throws Exception {
        java.util.Scanner sc = new java.util.Scanner(System.in);
        System.out.print("Command: ");
        String command = sc.nextLine().trim().toUpperCase();
        switch (command) {
            case "HELP" -> System.out.println("HELP, EXIT, ABOUT");
            case "EXIT" -> System.out.println("Exit selected");
            case "ABOUT" -> System.out.println("Java 25 Gemini training");
            default -> System.out.println("Unknown command");
        }
        sc.close();
    }
}
