package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 80: Code explanation. */
public class Program080 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain a Java method line-by-line for beginners.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
