package com.training.gemini;

/** Program 144: FileSizeCheck. Java-only practice helper. */
public class Program144 {
    public static void main(String[] args) throws Exception {
        if (args.length == 0) {
            System.out.println("Usage: Program144 file-path");
            return;
        }
        java.nio.file.Path path = java.nio.file.Path.of(args[0]);
        if (java.nio.file.Files.exists(path)) {
            long size = java.nio.file.Files.size(path);
            System.out.println("Bytes: " + size);
            System.out.println("MiB: " + (size / 1024.0 / 1024.0));
        } else System.out.println("File not found.");
    }
}
