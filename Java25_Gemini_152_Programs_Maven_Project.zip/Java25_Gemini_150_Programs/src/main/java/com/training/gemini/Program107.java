package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentConfig;
import com.google.genai.types.GenerateContentResponse;

/** Program 107: Candidate count. */
public class Program107 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain encapsulation in a short paragraph.";
        GenerateContentConfig config =
                GenerateContentConfig.builder()
                        .candidateCount(1)
                        .build();
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, config);
        System.out.println(response.text());
    }
}
