package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 7: Java history. */
public class Program007 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain Java's major characteristics in beginner-friendly bullet points.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
