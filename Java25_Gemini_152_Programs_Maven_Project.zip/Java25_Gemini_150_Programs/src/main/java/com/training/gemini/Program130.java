package com.training.gemini;

/** Program 130: TextCounter. Java-only practice helper. */
public class Program130 {
    public static void main(String[] args) throws Exception {
        String text = "Gemini SDK\nJava 25\nMaven";
        long words = java.util.Arrays.stream(text.split("\\s+")).filter(s -> !s.isBlank()).count();
        System.out.println("Characters: " + text.length());
        System.out.println("Words: " + words);
        System.out.println("Lines: " + text.lines().count());
    }
}
