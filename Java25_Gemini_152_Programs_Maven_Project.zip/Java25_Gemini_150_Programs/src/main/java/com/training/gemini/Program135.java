package com.training.gemini;

/** Program 135: JsonFileWriter. Java-only practice helper. */
public class Program135 {
    public static void main(String[] args) throws Exception {
        String json = "{\n  \\u0022topic\\u0022: \\u0022Java\\u0022,\n  \\u0022level\\u0022: \\u0022beginner\\u0022\n}";
        java.nio.file.Files.writeString(java.nio.file.Path.of("sample.json"), json);
        System.out.println("sample.json written.");
    }
}
