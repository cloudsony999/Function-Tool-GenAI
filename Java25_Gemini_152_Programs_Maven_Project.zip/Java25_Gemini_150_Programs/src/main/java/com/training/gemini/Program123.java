package com.training.gemini;
import com.google.genai.Client;
import com.google.genai.types.Content;
import com.google.genai.types.GenerateContentResponse;
import com.google.genai.types.Part;
/** Upload a PDF file and ask Gemini to summarize it. */
public class Program123 {
    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("Usage: Program123 document.pdf");
            return;
        }
        Client client = new Client();
        com.google.genai.types.File file = client.files.upload(args[0], null);
        Content content = Content.fromParts(
                Part.fromText("Summarize this PDF. List its key ideas and action items."),
                Part.fromUri(file.name().get(), file.mimeType().get()));
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", content, null);
        System.out.println(response.text());
    }
}