package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 58: Prompt injection. */
public class Program058 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain prompt injection using a harmless example and prevention.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
