package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 40: Output format. */
public class Program040 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Prompt Gemini to return a checklist with numbered items.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
