package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 35: System prompt. */
public class Program035 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain system instructions and show a reusable example.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
