package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 10: Java object. */
public class Program010 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain an object and show a tiny Java example.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
