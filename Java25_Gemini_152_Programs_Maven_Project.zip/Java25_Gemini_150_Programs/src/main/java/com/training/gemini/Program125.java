package com.training.gemini;
import com.google.genai.Client;
import com.google.genai.types.DeleteFileResponse;
/** Delete a file by the Files API resource name. */
public class Program125 {
    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("Usage: Program125 files/RESOURCE_NAME");
            return;
        }
        Client client = new Client();
        DeleteFileResponse response = client.files.delete(args[0], null);
        System.out.println("Delete response: " + response);
    }
}