package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 44: Rewrite. */
public class Program044 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Rewrite a rude customer message into a polite professional message.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
