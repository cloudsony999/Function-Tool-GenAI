package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 146: Prompt for MCQ generator. */
public class Program146 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Create 8 MCQs about Java exceptions. Include four choices and answer key.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
