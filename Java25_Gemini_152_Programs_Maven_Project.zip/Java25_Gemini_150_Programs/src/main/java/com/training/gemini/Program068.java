package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 68: Documentation. */
public class Program068 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Write a README outline for a Maven Java project.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
