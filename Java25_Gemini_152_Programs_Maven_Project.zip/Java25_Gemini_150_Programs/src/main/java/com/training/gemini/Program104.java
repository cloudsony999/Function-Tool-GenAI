package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentConfig;
import com.google.genai.types.GenerateContentResponse;

/** Program 104: Top P. */
public class Program104 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Suggest names for a beginner Java learning application.";
        GenerateContentConfig config =
                GenerateContentConfig.builder()
                        .topP(0.8f)
                        .build();
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, config);
        System.out.println(response.text());
    }
}
