package com.training.gemini;

/** Program 131: InputValidator. Java-only practice helper. */
public class Program131 {
    public static void main(String[] args) throws Exception {
        java.util.Scanner sc = new java.util.Scanner(System.in);
        System.out.print("Prompt: ");
        String prompt = sc.nextLine();
        if (prompt.isBlank()) System.out.println("Prompt cannot be blank.");
        else if (prompt.length() > 5000) System.out.println("Prompt is too long.");
        else System.out.println("Prompt accepted (" + prompt.length() + " characters).");
        sc.close();
    }
}
