package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 60: Product description. */
public class Program060 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Write a product description for a fictional eco-friendly water bottle.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
