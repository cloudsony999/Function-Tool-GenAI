package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 64: Study plan. */
public class Program064 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Create a 7-day beginner plan for Java 25.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
