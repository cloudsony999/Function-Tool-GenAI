package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 70: Decision. */
public class Program070 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Recommend whether a beginner should learn Java or Python first, with balanced reasoning.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
