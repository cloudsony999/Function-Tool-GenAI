package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 67: Test cases. */
public class Program067 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Generate test cases for a method that validates an email address.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
