package com.training.gemini;

/** Program 143: ApiKeyCheck. Java-only practice helper. */
public class Program143 {
    public static void main(String[] args) throws Exception {
        String key = System.getenv("GOOGLE_API_KEY");
        System.out.println(key == null || key.isBlank()
                ? "GOOGLE_API_KEY is not set."
                : "GOOGLE_API_KEY is configured (value hidden).");
    }
}
