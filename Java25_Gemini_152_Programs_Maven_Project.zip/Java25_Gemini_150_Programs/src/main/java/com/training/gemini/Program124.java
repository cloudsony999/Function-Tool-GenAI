package com.training.gemini;
import com.google.genai.Client;
import com.google.genai.types.ListFilesConfig;
/** List files uploaded to the Gemini Files API. */
public class Program124 {
    public static void main(String[] args) {
        Client client = new Client();
        System.out.println("Uploaded files:");
        for (com.google.genai.types.File file :
                client.files.list(ListFilesConfig.builder().pageSize(10).build())) {
            System.out.println(file.name().orElse("(no name)") + " | "
                    + file.mimeType().orElse("(unknown type)"));
        }
    }
}