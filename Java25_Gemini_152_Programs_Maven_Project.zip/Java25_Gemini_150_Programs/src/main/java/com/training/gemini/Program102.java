package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentConfig;
import com.google.genai.types.GenerateContentResponse;

/** Program 102: Temperature balanced. */
public class Program102 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain Java interfaces and give a practical example.";
        GenerateContentConfig config =
                GenerateContentConfig.builder()
                        .temperature(0.5f)
                        .build();
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, config);
        System.out.println(response.text());
    }
}
