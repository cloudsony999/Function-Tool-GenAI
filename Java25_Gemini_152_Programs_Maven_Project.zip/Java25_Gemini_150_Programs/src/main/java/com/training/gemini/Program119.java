package com.training.gemini;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.genai.Client;
import com.google.genai.types.GenerateContentConfig;
import com.google.genai.types.GenerateContentResponse;
/** Constrain the response to a JSON schema. */
public class Program119 {
    public static void main(String[] args) {
        Client client = new Client();
        ImmutableMap<String, Object> schema = ImmutableMap.of(
                "type", "object",
                "properties", ImmutableMap.of(
                        "topic", ImmutableMap.of("type", "string"),
                        "tips", ImmutableMap.of(
                                "type", "array",
                                "items", ImmutableMap.of("type", "string"))),
                "required", ImmutableList.of("topic", "tips"));
        GenerateContentConfig config = GenerateContentConfig.builder()
                .responseMimeType("application/json")
                .candidateCount(1)
                .responseSchema(schema)
                .build();
        GenerateContentResponse response =
                client.models.generateContent(
                        "gemini-3.8-flash", "Give three Java learning tips.", config);
        System.out.println(response.text());
    }
}