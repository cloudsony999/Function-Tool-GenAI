package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 6: Prompt basics. */
public class Program006 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain what a prompt is and show a weak prompt versus a better prompt.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
