package com.training.gemini;
import com.google.genai.Client;
import com.google.genai.ResponseStream;
import com.google.genai.types.GenerateContentResponse;
/** Stream text chunks as the model produces them. */
public class Program116 {
    public static void main(String[] args) {
        Client client = new Client();
        ResponseStream<GenerateContentResponse> stream =
                client.models.generateContentStream(
                        "gemini-3.8-flash", "Tell a 250-word story about a robot.", null);
        try {
            for (GenerateContentResponse chunk : stream) {
                System.out.print(chunk.text());
            }
        } finally {
            stream.close();
        }
    }
}