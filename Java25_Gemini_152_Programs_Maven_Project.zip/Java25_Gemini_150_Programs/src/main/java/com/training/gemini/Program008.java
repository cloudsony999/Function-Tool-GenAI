package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 8: Java JVM. */
public class Program008 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain JVM, JRE and JDK and show how they relate.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
