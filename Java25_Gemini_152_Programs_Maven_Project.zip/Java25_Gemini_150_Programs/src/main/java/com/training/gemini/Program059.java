package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 59: Customer support. */
public class Program059 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Write a helpful customer support response for a delayed delivery.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
