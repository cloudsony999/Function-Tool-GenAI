package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 75: Classifier. */
public class Program075 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Classify a message as QUESTION, COMPLAINT or FEEDBACK and explain briefly.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
