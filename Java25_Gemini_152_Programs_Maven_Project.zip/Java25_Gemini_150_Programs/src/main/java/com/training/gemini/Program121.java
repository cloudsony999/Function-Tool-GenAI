package com.training.gemini;
import com.google.genai.Client;
import com.google.genai.types.Content;
import com.google.genai.types.GenerateContentResponse;
import com.google.genai.types.Part;
/** Upload a local image, then ask a vision-capable model to analyze it. */
public class Program121 {
    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("Usage: mvn exec:java -Dexec.mainClass=com.training.gemini.Program121 -Dexec.args=photo.jpg");
            return;
        }
        Client client = new Client();
        com.google.genai.types.File file = client.files.upload(args[0], null);
        Content content = Content.fromParts(
                Part.fromText("Describe this image and identify visible text."),
                Part.fromUri(file.name().get(), file.mimeType().get()));
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", content, null);
        System.out.println(response.text());
    }
}