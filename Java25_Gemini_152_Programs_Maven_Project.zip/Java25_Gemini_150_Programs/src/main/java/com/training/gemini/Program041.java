package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 41: Audience targeting. */
public class Program041 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain inheritance to a 10-year-old and then to a college student.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
