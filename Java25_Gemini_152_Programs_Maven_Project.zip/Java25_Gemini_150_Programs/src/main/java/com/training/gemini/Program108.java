package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentConfig;
import com.google.genai.types.GenerateContentResponse;

/** Program 108: Stop sequence. */
public class Program108 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain Java in three sentences and finish with END.";
        GenerateContentConfig config =
                GenerateContentConfig.builder()
                        .stopSequences(java.util.List.of("END"))
                        .build();
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, config);
        System.out.println(response.text());
    }
}
