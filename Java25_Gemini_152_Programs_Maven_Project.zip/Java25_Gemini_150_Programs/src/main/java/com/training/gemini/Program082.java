package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 82: Data structure. */
public class Program082 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Compare stack and queue using real-life examples.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
