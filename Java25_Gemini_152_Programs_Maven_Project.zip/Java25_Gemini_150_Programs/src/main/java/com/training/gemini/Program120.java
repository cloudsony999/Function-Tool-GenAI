package com.training.gemini;
import com.google.genai.Client;
import com.google.genai.types.GenerateContentConfig;
import com.google.genai.types.GenerateContentResponse;
import com.google.genai.types.Tool;
import java.lang.reflect.Method;
/** Automatic function calling with a harmless local function. */
public class Program120 {
    public static String getTrainingSchedule(String topic) {
        return "A sample schedule for " + topic + ": Day 1 basics; Day 2 practice.";
    }
    public static void main(String[] args) throws NoSuchMethodException {
        Client client = new Client();
        Method method = Program120.class.getMethod("getTrainingSchedule", String.class);
        GenerateContentConfig config =
                GenerateContentConfig.builder().tools(Tool.builder().functions(method)).build();
        GenerateContentResponse response = client.models.generateContent(
                "gemini-3.8-flash", "Create a Java training schedule for beginners.", config);
        System.out.println(response.text());
        response.automaticFunctionCallingHistory().ifPresent(System.out::println);
    }
}