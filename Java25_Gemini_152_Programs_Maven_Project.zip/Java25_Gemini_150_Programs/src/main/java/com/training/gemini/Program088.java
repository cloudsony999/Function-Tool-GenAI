package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 88: Tokens. */
public class Program088 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain input tokens, output tokens and context window.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
