package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 65: Code review. */
public class Program065 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Review a simple Java snippet conceptually and list possible improvements.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
