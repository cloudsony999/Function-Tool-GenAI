package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 38: Role prompt. */
public class Program038 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Create a role prompt for a Java programming tutor.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
