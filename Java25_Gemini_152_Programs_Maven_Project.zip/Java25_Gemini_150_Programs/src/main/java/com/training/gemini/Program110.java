package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentConfig;
import com.google.genai.types.GenerateContentResponse;

/** Program 110: Thinking config. */
public class Program110 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain the difference between an interface and an abstract class.";
        GenerateContentConfig config =
                GenerateContentConfig.builder()
                        .thinkingConfig(com.google.genai.types.ThinkingConfig.builder().thinkingBudget(0).build())
                        .build();
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, config);
        System.out.println(response.text());
    }
}
