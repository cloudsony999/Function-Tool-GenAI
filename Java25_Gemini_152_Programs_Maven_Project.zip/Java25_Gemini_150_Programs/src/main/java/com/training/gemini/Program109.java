package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentConfig;
import com.google.genai.types.GenerateContentResponse;

/** Program 109: System instruction. */
public class Program109 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain polymorphism.";
        GenerateContentConfig config =
                GenerateContentConfig.builder()
                        .systemInstruction(com.google.genai.types.Content.fromParts(com.google.genai.types.Part.fromText("You are a patient Java tutor. Explain simply and use examples.")))
                        .build();
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, config);
        System.out.println(response.text());
    }
}
