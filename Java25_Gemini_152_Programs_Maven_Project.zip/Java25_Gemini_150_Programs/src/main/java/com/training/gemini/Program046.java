package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 46: Resume. */
public class Program046 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Create a fictional junior Java developer resume summary.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
