package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 12: Data types. */
public class Program012 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain Java primitive data types in a compact table.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
