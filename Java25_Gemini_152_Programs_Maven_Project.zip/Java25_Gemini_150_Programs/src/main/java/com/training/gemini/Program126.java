package com.training.gemini;

/** Program 126: PromptBuilder. Java-only practice helper. */
public class Program126 {
    public static void main(String[] args) throws Exception {
        String role = "You are a beginner-friendly Java trainer.";
        String context = "Audience: BCA student; Java 25.";
        String task = "Explain the Stream API.";
        String output = "Definition, example, code, output.";
        String prompt = role + "\n\n" + context + "\n\nTASK: " + task + "\n\nOUTPUT: " + output;
        System.out.println(prompt);
    }
}
