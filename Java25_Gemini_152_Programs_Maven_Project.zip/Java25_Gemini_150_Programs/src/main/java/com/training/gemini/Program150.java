package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 150: Prompt for project requirements. */
public class Program150 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Write requirements for a Java console-based expense tracker.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
