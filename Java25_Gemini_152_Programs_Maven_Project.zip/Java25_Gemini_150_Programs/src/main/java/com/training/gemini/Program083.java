package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 83: Security. */
public class Program083 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "List safe practices for storing API keys in Java applications.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
