package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 30: Streams. */
public class Program030 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain Stream filter and map with an employee-like example.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
