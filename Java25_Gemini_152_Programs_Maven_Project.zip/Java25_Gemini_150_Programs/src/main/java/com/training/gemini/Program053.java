package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 53: Python. */
public class Program053 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain Python lists to a beginner and include a short code sample.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
