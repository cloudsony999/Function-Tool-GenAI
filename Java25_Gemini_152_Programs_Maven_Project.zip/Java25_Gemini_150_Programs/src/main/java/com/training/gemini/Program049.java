package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 49: Quiz. */
public class Program049 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Create a 10-question beginner quiz on Maven, with answers after the questions.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
