package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 2: AI definition. */
public class Program002 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain Artificial Intelligence to a BCA beginner with one real-life example.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
