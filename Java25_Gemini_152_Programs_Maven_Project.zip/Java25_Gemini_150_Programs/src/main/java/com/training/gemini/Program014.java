package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 14: If else. */
public class Program014 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain if/else using an ATM withdrawal scenario.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
