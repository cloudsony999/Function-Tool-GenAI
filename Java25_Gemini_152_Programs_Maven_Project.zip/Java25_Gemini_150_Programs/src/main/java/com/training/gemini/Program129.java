package com.training.gemini;

/** Program 129: ConversationFile. Java-only practice helper. */
public class Program129 {
    public static void main(String[] args) throws Exception {
        String transcript = "USER: Hello\nMODEL: Hi!\n";
        java.nio.file.Path path = java.nio.file.Path.of("conversation.txt");
        java.nio.file.Files.writeString(path, transcript);
        System.out.println("Saved: " + path.toAbsolutePath());
    }
}
