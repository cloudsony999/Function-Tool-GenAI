package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 25: Interface. */
public class Program025 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Teach Java interfaces with a simple runnable program.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
