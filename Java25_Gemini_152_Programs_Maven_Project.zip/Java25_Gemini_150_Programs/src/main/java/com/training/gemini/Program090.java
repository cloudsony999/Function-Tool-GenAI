package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 90: Top P. */
public class Program090 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain top-p sampling without math-heavy language.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
