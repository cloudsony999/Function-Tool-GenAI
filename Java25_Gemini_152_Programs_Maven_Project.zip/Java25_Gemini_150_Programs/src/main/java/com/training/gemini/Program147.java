package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 147: Prompt for lesson plan. */
public class Program147 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Create a 60-minute classroom lesson plan about Java interfaces.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
