package com.training.gemini;

/** Program 137: RetryDemo. Java-only practice helper. */
public class Program137 {
    public static void main(String[] args) throws Exception {
        int maxAttempts = 3;
        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            System.out.println("Attempt " + attempt);
            boolean simulatedSuccess = attempt == 3;
            if (simulatedSuccess) {
                System.out.println("Simulated success.");
                break;
            }
            if (attempt == maxAttempts) System.out.println("Giving up after bounded retries.");
        }
    }
}
