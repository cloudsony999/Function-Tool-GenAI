package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 51: SQL. */
public class Program051 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain SQL joins with a small illustrative example.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
