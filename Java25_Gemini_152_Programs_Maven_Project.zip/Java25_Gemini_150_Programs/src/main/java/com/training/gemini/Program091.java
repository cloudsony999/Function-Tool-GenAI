package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 91: Top K. */
public class Program091 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain top-k sampling using a candidate list analogy.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
