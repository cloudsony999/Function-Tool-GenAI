package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentConfig;
import com.google.genai.types.GenerateContentResponse;

/** Program 113: Combined settings. */
public class Program113 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain Java 25 switch expressions with code.";
        GenerateContentConfig config =
                GenerateContentConfig.builder()
                        .temperature(0.2f).maxOutputTokens(250).candidateCount(1)
                        .build();
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, config);
        System.out.println(response.text());
    }
}
