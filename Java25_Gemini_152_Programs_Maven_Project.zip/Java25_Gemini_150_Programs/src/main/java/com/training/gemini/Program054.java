package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 54: Data science. */
public class Program054 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain pandas DataFrame using a table analogy.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
