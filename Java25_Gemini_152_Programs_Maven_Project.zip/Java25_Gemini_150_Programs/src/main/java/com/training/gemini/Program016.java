package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 16: Loops. */
public class Program016 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Compare for, while and do-while loops with examples.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
