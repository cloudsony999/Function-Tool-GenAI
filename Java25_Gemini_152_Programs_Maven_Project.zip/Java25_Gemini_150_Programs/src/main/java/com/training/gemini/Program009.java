package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 9: Java class. */
public class Program009 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain a Java class using a blueprint analogy.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
