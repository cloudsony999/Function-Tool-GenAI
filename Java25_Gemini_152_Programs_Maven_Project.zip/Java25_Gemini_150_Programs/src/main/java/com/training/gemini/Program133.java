package com.training.gemini;

/** Program 133: TemperatureRange. Java-only practice helper. */
public class Program133 {
    public static void main(String[] args) throws Exception {
        double temperature = args.length > 0 ? Double.parseDouble(args[0]) : 0.5;
        if (temperature < 0 || temperature > 2) {
            System.out.println("Outside commonly documented range; check model docs.");
        } else {
            System.out.println("Value accepted for this demo: " + temperature);
        }
    }
}
