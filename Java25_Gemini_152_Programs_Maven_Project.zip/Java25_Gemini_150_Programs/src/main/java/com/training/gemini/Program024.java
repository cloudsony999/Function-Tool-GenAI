package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 24: Abstraction. */
public class Program024 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain abstraction and compare abstract classes and interfaces.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
