package com.training.gemini;
import com.google.genai.Client;
import com.google.genai.types.Content;
import com.google.genai.types.GenerateContentResponse;
import com.google.genai.types.Part;
/** Upload an audio file and request a transcript/summary. */
public class Program122 {
    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("Usage: Program122 audio-file");
            return;
        }
        Client client = new Client();
        com.google.genai.types.File file = client.files.upload(args[0], null);
        Content content = Content.fromParts(
                Part.fromText("Transcribe the audio and then summarize it."),
                Part.fromUri(file.name().get(), file.mimeType().get()));
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", content, null);
        System.out.println(response.text());
    }
}