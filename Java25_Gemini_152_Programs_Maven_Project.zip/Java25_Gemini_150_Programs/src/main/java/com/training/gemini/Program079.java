package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 79: Code generator. */
public class Program079 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Generate a Java method to calculate factorial iteratively.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
