package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 39: Constraints. */
public class Program039 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain how constraints improve prompts. Show a before and after.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
