package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 13: Operators. */
public class Program013 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain arithmetic operators in Java with examples.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
