package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 56: Responsible AI. */
public class Program056 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain responsible AI, bias, privacy and verification.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
