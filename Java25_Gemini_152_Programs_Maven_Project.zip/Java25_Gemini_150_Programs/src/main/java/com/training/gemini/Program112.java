package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentConfig;
import com.google.genai.types.GenerateContentResponse;

/** Program 112: Safety settings. */
public class Program112 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain responsible AI.";
        GenerateContentConfig config =
                GenerateContentConfig.builder()
                        .safetySettings(java.util.List.of(com.google.genai.types.SafetySetting.builder().category(com.google.genai.types.HarmCategory.Known.HARM_CATEGORY_HATE_SPEECH).threshold(com.google.genai.types.HarmBlockThreshold.Known.BLOCK_ONLY_HIGH).build()))
                        .build();
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, config);
        System.out.println(response.text());
    }
}
