package com.training.gemini;

/** Program 140: ResponseFormatter. Java-only practice helper. */
public class Program140 {
    public static void main(String[] args) throws Exception {
        String response = "Java is platform independent.\nIt runs on the JVM.";
        String formatted = "=== AI RESPONSE ===\n" + response.strip() + "\n==================";
        System.out.println(formatted);
    }
}
