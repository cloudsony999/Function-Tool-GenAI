package com.training.gemini;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;

/** Program 37: Few-shot. */
public class Program037 {
    public static void main(String[] args) {
        Client client = new Client();
        String prompt = "Explain few-shot prompting with two examples and a final task.";
        GenerateContentResponse response =
                client.models.generateContent("gemini-3.8-flash", prompt, null);
        System.out.println("Prompt: " + prompt);
        System.out.println("\nGemini response:\n" + response.text());
    }
}
