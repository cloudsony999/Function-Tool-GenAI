weather_data = {
    "Kolkata": {"temperature_c": 31, "condition": "Cloudy"},
    "Delhi": {"temperature_c": 28, "condition": "Sunny"},
    "Chennai": {"temperature_c": 33, "condition": "Humid"}
}

def get_weather(city):
    return weather_data.get(city, {"error": "City not found"})

weather_tool = {
    "type": "function",
    "name": "get_weather",
    "description": "Get weather for a city from demo data.",
    "parameters": {
        "type": "object",
        "properties": {"city": {"type": "string"}},
        "required": ["city"],
        "additionalProperties": False
    },
    "strict": True
}

# User: "Is it hot in Kolkata today?"
# The model calls get_weather(city="Kolkata").
