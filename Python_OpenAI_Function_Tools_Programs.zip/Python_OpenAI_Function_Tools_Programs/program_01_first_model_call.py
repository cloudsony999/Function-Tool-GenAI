from openai import OpenAI

client = OpenAI()
response = client.responses.create(
    model="gpt-6.2-astra",
    input="Explain function tools in two lines."
)
print(response.output_text)

