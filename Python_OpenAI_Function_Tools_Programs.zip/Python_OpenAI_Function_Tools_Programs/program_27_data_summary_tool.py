sales = [1200, 1800, 950, 2400, 1600]

def summarize_sales():
    return {
        "count": len(sales),
        "total": sum(sales),
        "average": sum(sales) / len(sales),
        "minimum": min(sales),
        "maximum": max(sales)
    }

summary_tool = {
    "type": "function",
    "name": "summarize_sales",
    "description": "Return descriptive statistics for demo sales data.",
    "parameters": {
        "type": "object",
        "properties": {},
        "required": [],
        "additionalProperties": False
    },
    "strict": True
}
