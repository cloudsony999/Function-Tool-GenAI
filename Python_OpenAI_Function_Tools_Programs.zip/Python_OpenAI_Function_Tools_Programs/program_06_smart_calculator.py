def calculate(a, b, operation):
    if operation == "add":
        return a + b
    if operation == "subtract":
        return a - b
    if operation == "multiply":
        return a * b
    if operation == "divide":
        if b == 0:
            return {"error": "Cannot divide by zero"}
        return a / b
    return {"error": "Unsupported operation"}

calculator_tool = {
    "type": "function",
    "name": "calculate",
    "description": "Perform arithmetic using two numbers and an operation.",
    "parameters": {
        "type": "object",
        "properties": {
            "a": {"type": "number"},
            "b": {"type": "number"},
            "operation": {
                "type": "string",
                "enum": ["add", "subtract", "multiply", "divide"]
            }
        },
        "required": ["a", "b", "operation"],
        "additionalProperties": False
    },
    "strict": True
}

# Prompt example:
# "Calculate 45 multiplied by 12."
# Tool arguments: {"a":45,"b":12,"operation":"multiply"}
