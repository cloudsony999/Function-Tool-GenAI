def calculate_gst(amount, gst_percent):
    if amount < 0 or gst_percent < 0:
        return {"error": "Values cannot be negative"}

    gst = amount * gst_percent / 100
    return {
        "base_amount": round(amount, 2),
        "gst_percent": gst_percent,
        "gst_amount": round(gst, 2),
        "final_amount": round(amount + gst, 2)
    }

gst_tool = {
    "type": "function",
    "name": "calculate_gst",
    "description": "Calculate GST and final amount.",
    "parameters": {
        "type": "object",
        "properties": {
            "amount": {"type": "number"},
            "gst_percent": {"type": "number"}
        },
        "required": ["amount", "gst_percent"],
        "additionalProperties": False
    },
    "strict": True
}

# User: "Calculate 18% GST on 2500."
# Result: base 2500, GST 450, total 2950.
