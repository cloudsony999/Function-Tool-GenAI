demo_rates = {"USD_INR": 83.0, "EUR_INR": 90.0}

def convert_currency(amount, pair):
    if pair not in demo_rates:
        return {"error": "Conversion pair not supported"}
    if amount < 0:
        return {"error": "Amount cannot be negative"}
    rate = demo_rates[pair]
    return {
        "amount": amount,
        "pair": pair,
        "demo_rate": rate,
        "converted_amount": round(amount * rate, 2)
    }

currency_tool = {
    "type": "function",
    "name": "convert_currency",
    "description": "Convert currency using a demo exchange rate.",
    "parameters": {
        "type": "object",
        "properties": {
            "amount": {"type": "number"},
            "pair": {"type": "string", "enum": ["USD_INR", "EUR_INR"]}
        },
        "required": ["amount", "pair"],
        "additionalProperties": False
    },
    "strict": True
}
