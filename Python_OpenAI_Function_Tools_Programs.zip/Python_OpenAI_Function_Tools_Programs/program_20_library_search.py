books = [
    {"title": "Python Basics", "author": "A. Sharma", "available": True},
    {"title": "AI Fundamentals", "author": "R. Das", "available": False},
    {"title": "Data Science", "author": "M. Roy", "available": True}
]

def search_books(keyword):
    keyword = keyword.lower()
    results = [
        book for book in books
        if keyword in book["title"].lower()
        or keyword in book["author"].lower()
    ]
    return results

book_tool = {
    "type": "function",
    "name": "search_books",
    "description": "Search library books by title or author keyword.",
    "parameters": {
        "type": "object",
        "properties": {"keyword": {"type": "string"}},
        "required": ["keyword"],
        "additionalProperties": False
    },
    "strict": True
}
