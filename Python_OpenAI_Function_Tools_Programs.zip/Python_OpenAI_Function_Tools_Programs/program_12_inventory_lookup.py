inventory = {
    "laptop": {"stock": 8, "price": 55000},
    "mouse": {"stock": 25, "price": 700},
    "keyboard": {"stock": 12, "price": 1500}
}

def check_stock(product):
    return inventory.get(product.lower(), {"error": "Product not found"})

inventory_tool = {
    "type": "function",
    "name": "check_stock",
    "description": "Check stock quantity and price for a product.",
    "parameters": {
        "type": "object",
        "properties": {"product": {"type": "string"}},
        "required": ["product"],
        "additionalProperties": False
    },
    "strict": True
}

# Prompt: "Do we have any keyboards in stock?"
# Tool returns the keyboard record.
