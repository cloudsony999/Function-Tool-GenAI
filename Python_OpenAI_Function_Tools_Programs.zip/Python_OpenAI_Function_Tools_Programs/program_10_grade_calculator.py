def calculate_grade(marks):
    if not 0 <= marks <= 100:
        return {"error": "Marks must be between 0 and 100"}

    if marks >= 90:
        grade = "A+"
    elif marks >= 80:
        grade = "A"
    elif marks >= 70:
        grade = "B"
    elif marks >= 60:
        grade = "C"
    elif marks >= 50:
        grade = "D"
    else:
        grade = "F"

    return {"marks": marks, "grade": grade}

grade_tool = {
    "type": "function",
    "name": "calculate_grade",
    "description": "Calculate a student's grade from marks out of 100.",
    "parameters": {
        "type": "object",
        "properties": {"marks": {"type": "number"}},
        "required": ["marks"],
        "additionalProperties": False
    },
    "strict": True
}
