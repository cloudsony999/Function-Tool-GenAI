students = {
    "BCA101": {"name": "Riya", "marks": 87, "course": "BCA"},
    "BCA102": {"name": "Arjun", "marks": 72, "course": "BCA"},
    "BCA103": {"name": "Meera", "marks": 91, "course": "BCA"}
}

def find_student(student_id):
    return students.get(student_id, {"error": "Student not found"})

student_tool = {
    "type": "function",
    "name": "find_student",
    "description": "Retrieve a student record by ID.",
    "parameters": {
        "type": "object",
        "properties": {"student_id": {"type": "string"}},
        "required": ["student_id"],
        "additionalProperties": False
    },
    "strict": True
}

# User: "Find BCA101 and tell me their marks."
# Python returns the record; LLM summarizes it.
