def calculate_attendance(attended, conducted, threshold=75):
    if conducted <= 0:
        return {"error": "Conducted classes must be greater than zero"}
    if attended < 0 or attended > conducted:
        return {"error": "Invalid attended count"}

    percentage = attended / conducted * 100
    return {
        "attended": attended,
        "conducted": conducted,
        "percentage": round(percentage, 2),
        "meets_threshold": percentage >= threshold,
        "threshold": threshold
    }

attendance_tool = {
    "type": "function",
    "name": "calculate_attendance",
    "description": "Calculate attendance percentage and threshold eligibility.",
    "parameters": {
        "type": "object",
        "properties": {
            "attended": {"type": "integer"},
            "conducted": {"type": "integer"},
            "threshold": {"type": "number"}
        },
        "required": ["attended", "conducted", "threshold"],
        "additionalProperties": False
    },
    "strict": True
}
