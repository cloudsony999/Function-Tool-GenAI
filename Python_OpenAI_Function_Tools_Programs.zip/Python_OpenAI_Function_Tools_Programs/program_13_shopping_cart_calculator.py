def calculate_order(product, quantity):
    product = product.lower()
    if product not in inventory:
        return {"error": "Product not found"}

    item = inventory[product]
    if quantity <= 0:
        return {"error": "Quantity must be positive"}
    if quantity > item["stock"]:
        return {"error": "Insufficient stock", "available": item["stock"]}

    return {
        "product": product,
        "quantity": quantity,
        "unit_price": item["price"],
        "total": item["price"] * quantity
    }

order_tool = {
    "type": "function",
    "name": "calculate_order",
    "description": "Check stock and calculate order total. Does not place order.",
    "parameters": {
        "type": "object",
        "properties": {
            "product": {"type": "string"},
            "quantity": {"type": "integer"}
        },
        "required": ["product", "quantity"],
        "additionalProperties": False
    },
    "strict": True
}
