# Illustrative dispatch map
FUNCTIONS = {
    "check_stock": check_stock,
    "calculate_order": calculate_order,
    "create_ticket": create_ticket
}

# Tool schemas should be combined:
# TOOLS = [inventory_tool, order_tool, ticket_tool]
#
# Example prompts:
# 1. "Check stock of mouse."
# 2. "Can I order 3 mice? Calculate the total."
# 3. "There is a problem with my keyboard. Create a medium priority ticket."
#
# For order placement or ticket submission:
# show a confirmation preview first, then execute only after user approval.
