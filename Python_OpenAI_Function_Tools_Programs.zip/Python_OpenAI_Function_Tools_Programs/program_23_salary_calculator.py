def calculate_salary(basic, hra_percent, allowance, deduction):
    if min(basic, allowance, deduction) < 0:
        return {"error": "Negative input not allowed"}

    hra = basic * hra_percent / 100
    gross = basic + hra + allowance
    net = gross - deduction

    return {
        "basic": basic,
        "hra": round(hra, 2),
        "allowance": allowance,
        "gross": round(gross, 2),
        "deduction": deduction,
        "net": round(net, 2)
    }

salary_tool = {
    "type": "function",
    "name": "calculate_salary",
    "description": "Calculate sample gross and net salary.",
    "parameters": {
        "type": "object",
        "properties": {
            "basic": {"type": "number"},
            "hra_percent": {"type": "number"},
            "allowance": {"type": "number"},
            "deduction": {"type": "number"}
        },
        "required": ["basic", "hra_percent", "allowance", "deduction"],
        "additionalProperties": False
    },
    "strict": True
}
