def add_numbers(a, b):
    return a + b

tools = [{
    "type": "function",
    "name": "add_numbers",
    "description": "Add two numbers.",
    "parameters": {
        "type": "object",
        "properties": {
            "a": {"type": "number"},
            "b": {"type": "number"}
        },
        "required": ["a", "b"],
        "additionalProperties": False
    },
    "strict": True
}]

