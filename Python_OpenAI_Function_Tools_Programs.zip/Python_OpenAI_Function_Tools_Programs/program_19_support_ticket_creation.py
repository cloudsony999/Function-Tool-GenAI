tickets = []
next_ticket_id = 1001

def create_ticket(category, description, priority):
    global next_ticket_id
    ticket = {
        "ticket_id": next_ticket_id,
        "category": category,
        "description": description,
        "priority": priority,
        "status": "Open"
    }
    tickets.append(ticket)
    next_ticket_id += 1
    return ticket

ticket_tool = {
    "type": "function",
    "name": "create_ticket",
    "description": "Create a support ticket from a user issue.",
    "parameters": {
        "type": "object",
        "properties": {
            "category": {"type": "string"},
            "description": {"type": "string"},
            "priority": {"type": "string", "enum": ["low", "medium", "high"]}
        },
        "required": ["category", "description", "priority"],
        "additionalProperties": False
    },
    "strict": True
}
