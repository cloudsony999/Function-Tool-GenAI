notes = [
    "Python functions can be reused.",
    "Function tools connect models with applications.",
    "Strict schemas help define expected arguments.",
    "Always validate model-provided inputs."
]

def search_notes(keyword):
    keyword = keyword.lower()
    return [note for note in notes if keyword in note.lower()]

search_tool = {
    "type": "function",
    "name": "search_notes",
    "description": "Search stored text notes for a keyword.",
    "parameters": {
        "type": "object",
        "properties": {"keyword": {"type": "string"}},
        "required": ["keyword"],
        "additionalProperties": False
    },
    "strict": True
}
