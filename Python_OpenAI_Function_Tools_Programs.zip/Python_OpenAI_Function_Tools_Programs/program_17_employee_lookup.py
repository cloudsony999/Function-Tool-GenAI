employees = {
    "E101": {"name": "Amit", "department": "IT", "salary": 60000},
    "E102": {"name": "Neha", "department": "HR", "salary": 52000}
}

def find_employee(employee_id):
    return employees.get(employee_id, {"error": "Employee not found"})

employee_tool = {
    "type": "function",
    "name": "find_employee",
    "description": "Find an employee record by employee ID.",
    "parameters": {
        "type": "object",
        "properties": {"employee_id": {"type": "string"}},
        "required": ["employee_id"],
        "additionalProperties": False
    },
    "strict": True
}
