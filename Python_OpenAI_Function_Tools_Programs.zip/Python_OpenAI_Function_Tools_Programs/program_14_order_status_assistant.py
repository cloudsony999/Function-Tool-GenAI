orders = {
    "ORD1001": {"status": "Shipped", "eta": "2026-11-22"},
    "ORD1002": {"status": "Processing", "eta": "Not available"}
}

def get_order_status(order_id):
    if order_id not in orders:
        return {"error": "Order not found"}
    return {"order_id": order_id, **orders[order_id]}

order_status_tool = {
    "type": "function",
    "name": "get_order_status",
    "description": "Get status and estimated delivery for an order ID.",
    "parameters": {
        "type": "object",
        "properties": {"order_id": {"type": "string"}},
        "required": ["order_id"],
        "additionalProperties": False
    },
    "strict": True
}
