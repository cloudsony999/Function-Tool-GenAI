available_slots = {
    "2026-11-21": ["10:00", "11:30", "15:00"],
    "2026-11-22": ["09:30", "14:00"]
}

def check_slot(date, time):
    slots = available_slots.get(date, [])
    return {
        "date": date,
        "time": time,
        "available": time in slots
}

slot_tool = {
    "type": "function",
    "name": "check_slot",
    "description": "Check whether an appointment date and time is available.",
    "parameters": {
        "type": "object",
        "properties": {
            "date": {"type": "string", "description": "YYYY-MM-DD"},
            "time": {"type": "string", "description": "24-hour HH:MM"}
        },
        "required": ["date", "time"],
        "additionalProperties": False
    },
    "strict": True
}
