products = [
    {"name": "Laptop A", "price": 45000, "ram_gb": 8},
    {"name": "Laptop B", "price": 65000, "ram_gb": 16},
    {"name": "Laptop C", "price": 80000, "ram_gb": 16}
]

def recommend_laptop(max_budget, min_ram):
    matches = [
        p for p in products
        if p["price"] <= max_budget and p["ram_gb"] >= min_ram
    ]
    return matches

recommend_tool = {
    "type": "function",
    "name": "recommend_laptop",
    "description": "Find laptops under a budget with at least required RAM.",
    "parameters": {
        "type": "object",
        "properties": {
            "max_budget": {"type": "number"},
            "min_ram": {"type": "integer"}
        },
        "required": ["max_budget", "min_ram"],
        "additionalProperties": False
    },
    "strict": True
}
