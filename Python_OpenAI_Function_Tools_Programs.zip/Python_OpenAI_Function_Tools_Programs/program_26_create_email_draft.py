def create_email_draft(to, subject, body):
    if "@" not in to:
        return {"error": "Invalid email address"}

    return {
        "to": to,
        "subject": subject,
        "body": body,
        "status": "DRAFT_ONLY"
    }

email_draft_tool = {
    "type": "function",
    "name": "create_email_draft",
    "description": "Create an email draft but do not send it.",
    "parameters": {
        "type": "object",
        "properties": {
            "to": {"type": "string"},
            "subject": {"type": "string"},
            "body": {"type": "string"}
        },
        "required": ["to", "subject", "body"],
        "additionalProperties": False
    },
    "strict": True
}
