customers = {
    "C001": {"name": "Ananya", "city": "Kolkata", "segment": "Gold"},
    "C002": {"name": "Rahul", "city": "Delhi", "segment": "Silver"}
}

def get_customer(customer_id):
    return customers.get(customer_id, {"error": "Customer not found"})

customer_tool = {
    "type": "function",
    "name": "get_customer",
    "description": "Get customer details by customer ID.",
    "parameters": {
        "type": "object",
        "properties": {"customer_id": {"type": "string"}},
        "required": ["customer_id"],
        "additionalProperties": False
    },
    "strict": True
}
