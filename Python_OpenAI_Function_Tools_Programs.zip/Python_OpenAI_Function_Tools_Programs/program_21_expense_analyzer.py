def categorize_expense(description, amount):
    text = description.lower()

    if any(word in text for word in ["restaurant", "food", "cafe"]):
        category = "Food"
    elif any(word in text for word in ["uber", "taxi", "bus", "train"]):
        category = "Transport"
    elif any(word in text for word in ["movie", "music", "game"]):
        category = "Entertainment"
    else:
        category = "Other"

    return {
        "description": description,
        "amount": amount,
        "category": category
    }

expense_tool = {
    "type": "function",
    "name": "categorize_expense",
    "description": "Categorize an expense based on its description.",
    "parameters": {
        "type": "object",
        "properties": {
            "description": {"type": "string"},
            "amount": {"type": "number"}
        },
        "required": ["description", "amount"],
        "additionalProperties": False
    },
    "strict": True
}
