from openai import OpenAI

client = OpenAI()
tools = [{
    "type": "function",
    "name": "add_numbers",
    "description": "Add two numbers.",
    "parameters": {
        "type": "object",
        "properties": {"a": {"type": "number"}, "b": {"type": "number"}},
        "required": ["a", "b"],
        "additionalProperties": False
    },
    "strict": True
}]
response = client.responses.create(
    model="gpt-6.2-astra",
    input="What is 125 + 75?",
    tools=tools
)
for item in response.output:
    if item.type == "function_call":
        print(item.name, item.arguments, item.call_id)

