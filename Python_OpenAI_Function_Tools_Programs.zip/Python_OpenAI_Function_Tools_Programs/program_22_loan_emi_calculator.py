def calculate_emi(principal, annual_rate, months):
    if principal <= 0 or months <= 0 or annual_rate < 0:
        return {"error": "Invalid loan parameters"}

    monthly_rate = annual_rate / 12 / 100
    if monthly_rate == 0:
        emi = principal / months
    else:
        factor = (1 + monthly_rate) ** months
        emi = principal * monthly_rate * factor / (factor - 1)

    return {
        "principal": principal,
        "annual_rate_percent": annual_rate,
        "months": months,
        "emi": round(emi, 2),
        "total_payment": round(emi * months, 2),
        "total_interest": round(emi * months - principal, 2)
    }

emi_tool = {
    "type": "function",
    "name": "calculate_emi",
    "description": "Calculate monthly loan EMI and total payment.",
    "parameters": {
        "type": "object",
        "properties": {
            "principal": {"type": "number"},
            "annual_rate": {"type": "number"},
            "months": {"type": "integer"}
        },
        "required": ["principal", "annual_rate", "months"],
        "additionalProperties": False
    },
    "strict": True
}
