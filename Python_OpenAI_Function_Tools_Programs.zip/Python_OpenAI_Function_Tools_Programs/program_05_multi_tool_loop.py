import json
from openai import OpenAI

client = OpenAI()
MODEL = "gpt-6.2-astra"

# Define business functions here.
def add_numbers(a, b):
    return a + b

def subtract_numbers(a, b):
    return a - b

FUNCTIONS = {
    "add_numbers": add_numbers,
    "subtract_numbers": subtract_numbers
}

TOOLS = [
    {
        "type": "function",
        "name": "add_numbers",
        "description": "Add two numbers.",
        "parameters": {
            "type": "object",
            "properties": {
                "a": {"type": "number"},
                "b": {"type": "number"}
            },
            "required": ["a", "b"],
            "additionalProperties": False
        },
        "strict": True
    },
    {
        "type": "function",
        "name": "subtract_numbers",
        "description": "Subtract b from a.",
        "parameters": {
            "type": "object",
            "properties": {
                "a": {"type": "number"},
                "b": {"type": "number"}
            },
            "required": ["a", "b"],
            "additionalProperties": False
        },
        "strict": True
    }
]

def run_tool(name, arguments):
    if name not in FUNCTIONS:
        return {"error": "Unknown tool"}

    try:
        args = json.loads(arguments)
        return FUNCTIONS[name](**args)
    except Exception as exc:
        return {"error": str(exc)}

def ask_agent(user_question):
    response = client.responses.create(
        model=MODEL,
        input=user_question,
        tools=TOOLS,
        tool_choice="auto"
    )

    # Preserve model output and append each tool result.
    for _ in range(5):  # maximum tool rounds
        calls = [
            item for item in response.output
            if item.type == "function_call"
        ]

        if not calls:
            return response.output_text

        tool_outputs = []
        for call in calls:
            result = run_tool(call.name, call.arguments)
            tool_outputs.append({
                "type": "function_call_output",
                "call_id": call.call_id,
                "output": json.dumps(result)
            })

        response = client.responses.create(
            model=MODEL,
            input=[*response.output, *tool_outputs],
            tools=TOOLS
        )

    return "Stopped: maximum tool-call rounds reached."

print(ask_agent("Calculate 100 + 50, then subtract 20."))
