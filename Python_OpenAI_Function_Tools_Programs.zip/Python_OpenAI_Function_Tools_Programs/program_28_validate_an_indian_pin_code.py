import re

def validate_pin(pin):
    valid = bool(re.fullmatch(r"[1-9][0-9]{5}", pin))
    return {"pin": pin, "format_valid": valid}

pin_tool = {
    "type": "function",
    "name": "validate_pin",
    "description": "Validate whether a string has the six-digit Indian PIN format.",
    "parameters": {
        "type": "object",
        "properties": {"pin": {"type": "string"}},
        "required": ["pin"],
        "additionalProperties": False
    },
    "strict": True
}
