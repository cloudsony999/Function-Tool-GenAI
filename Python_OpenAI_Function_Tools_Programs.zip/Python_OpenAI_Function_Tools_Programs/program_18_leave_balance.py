leave_balances = {
    "E101": {"annual": 12, "sick": 5},
    "E102": {"annual": 8, "sick": 3}
}

def get_leave_balance(employee_id):
    return leave_balances.get(employee_id, {"error": "Employee not found"})

leave_tool = {
    "type": "function",
    "name": "get_leave_balance",
    "description": "Retrieve remaining annual and sick leave days.",
    "parameters": {
        "type": "object",
        "properties": {"employee_id": {"type": "string"}},
        "required": ["employee_id"],
        "additionalProperties": False
    },
    "strict": True
}
