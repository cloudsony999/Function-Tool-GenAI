import json
from openai import OpenAI

client = OpenAI()

def add_numbers(a, b):
    return a + b

tools = [{
    "type": "function",
    "name": "add_numbers",
    "description": "Add two numbers.",
    "parameters": {
        "type": "object",
        "properties": {
            "a": {"type": "number"},
            "b": {"type": "number"}
        },
        "required": ["a", "b"],
        "additionalProperties": False
    },
    "strict": True
}]

response = client.responses.create(
    model="gpt-6.2-astra",
    input="Add 125 and 75.",
    tools=tools
)

for item in response.output:
    if item.type == "function_call":
        args = json.loads(item.arguments)
        result = add_numbers(**args)

        response = client.responses.create(
            model="gpt-6.2-astra",
            input=[
                *response.output,
                {
                    "type": "function_call_output",
                    "call_id": item.call_id,
                    "output": str(result)
                }
            ],
            tools=tools
        )

print(response.output_text)
