# Python Function Tools with OpenAI — Programs

Install uv and create the project:
```powershell
powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
uv init
uv python install 3.13
uv python pin 3.13
uv add openai
$env:OPENAI_API_KEY="YOUR_API_KEY"
uv run python main.py
```

These files are training snippets. Many are function/schema examples; copy the desired tool(s) into the reusable multi-tool agent loop (`program_10_multi_tool_loop.py`) or create your own runner.

Model identifier is configurable in the programs. Select a model available to your API account.
